---
name: research-briefing-dashboard
description: Use when Codex has approved research meeting notes and needs to prepare a confidential, self-contained offline supervisor briefing.
---

# Research briefing dashboard

Build one offline HTML briefing from approved, sanitised meeting notes. Treat the eight input fields as the complete factual boundary.

## Prepare the input

Create UTF-8 JSON with exactly these keys:

```json
{
  "project_title": "…",
  "recent_progress": ["…"],
  "completed_work": ["…"],
  "key_findings": ["…"],
  "unresolved_questions": ["…"],
  "decisions_required": ["…"],
  "next_actions": ["…"],
  "timeline": ["…"]
}
```

Supply non-empty text for `project_title`. Supply an array of non-empty text for every other key; use an empty array when nothing was approved. Do not add keys.

Preserve wording and field placement. Never infer, combine, relabel or transfer content. In particular, do not turn an unresolved question into a finding or decision, and do not add dates, owners, risks, mitigations or actions that are absent from the supplied fields.

## Build and check

Run from the Skill directory:

```bash
python3 scripts/build_briefing.py INPUT.json OUTPUT.html
```

Open the generated file offline. Compare every displayed item with the corresponding JSON value. Confirm that all seven sections are present, empty arrays display exactly `No items supplied.`, and no new factual content or section has appeared. Correct the JSON and rebuild if the comparison fails; do not patch the generated HTML.

Return the generated HTML as the exact requested deliverable. Do not append an executive summary, recommendations, meeting record or speculative material.

## Confidentiality

Treat source notes and output as confidential. Use sanitised identifiers, keep the file in an approved local location and do not upload it to an external service.

## Common mistakes

- Omitting a required key instead of supplying an empty array.
- Adding participant, author, risk or meeting-date keys.
- Reframing questions as proposed decisions to make the briefing seem actionable.
- Editing the template or builder for one meeting rather than correcting the JSON.
- Sharing the file before completing the field-by-field comparison.
