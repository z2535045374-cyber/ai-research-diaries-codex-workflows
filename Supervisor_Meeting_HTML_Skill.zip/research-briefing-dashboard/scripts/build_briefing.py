#!/usr/bin/env python3
"""Build a self-contained supervisor briefing from a strict JSON contract."""

from __future__ import annotations

import html
import json
import os
import re
import sys
import tempfile
from pathlib import Path
from typing import Any, Iterable


SKILL_ROOT = Path(__file__).resolve().parents[1]
TEMPLATE_PATH = SKILL_ROOT / "assets" / "briefing_template.html"

PROJECT_TITLE = "project_title"
LIST_FIELDS = (
    "recent_progress",
    "completed_work",
    "key_findings",
    "unresolved_questions",
    "decisions_required",
    "next_actions",
    "timeline",
)
REQUIRED_FIELDS = (PROJECT_TITLE, *LIST_FIELDS)
FIELD_TOKENS = {
    "recent_progress": "RECENT_PROGRESS",
    "completed_work": "COMPLETED_WORK",
    "key_findings": "KEY_FINDINGS",
    "unresolved_questions": "UNRESOLVED_QUESTIONS",
    "decisions_required": "DECISIONS_REQUIRED",
    "next_actions": "NEXT_ACTIONS",
    "timeline": "TIMELINE",
}
EMPTY_MESSAGE = "No items supplied."
TOKEN_PATTERN = re.compile(r"\{\{([^{}]+)\}\}")


class InputError(ValueError):
    """Report invalid public input without creating output."""


class BuildError(RuntimeError):
    """Report an internal template or output failure."""


def _reject_duplicate_keys(pairs: Iterable[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise InputError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def _reject_non_standard_constant(value: str) -> None:
    raise InputError(f"Invalid JSON constant: {value}")


def load_input(path: Path) -> Any:
    try:
        raw_text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        raise InputError(f"Could not read input JSON: {exc}") from exc

    try:
        return json.loads(
            raw_text,
            object_pairs_hook=_reject_duplicate_keys,
            parse_constant=_reject_non_standard_constant,
        )
    except InputError:
        raise
    except json.JSONDecodeError as exc:
        raise InputError(
            f"Invalid JSON at line {exc.lineno}, column {exc.colno}: {exc.msg}"
        ) from exc


def validate_input(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise InputError("Top-level JSON value must be an object.")

    issues: list[str] = []
    supplied = set(payload)
    required = set(REQUIRED_FIELDS)

    missing = sorted(required - supplied)
    if missing:
        issues.append(f"Missing required key(s): {', '.join(missing)}")

    unknown = sorted(supplied - required)
    if unknown:
        issues.append(f"Unknown key(s): {', '.join(unknown)}")

    if PROJECT_TITLE in payload:
        title = payload[PROJECT_TITLE]
        if not isinstance(title, str) or not title.strip():
            issues.append("project_title must be non-empty text")

    for field in LIST_FIELDS:
        if field not in payload:
            continue
        value = payload[field]
        if not isinstance(value, list):
            issues.append(f"{field} must be an array of non-empty text")
            continue
        for index, item in enumerate(value):
            if not isinstance(item, str) or not item.strip():
                issues.append(
                    f"{field}[{index}] must be non-empty text"
                )

    if issues:
        raise InputError("; ".join(issues))

    return payload


def load_template() -> str:
    try:
        template = TEMPLATE_PATH.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        raise BuildError(f"Could not read briefing template: {exc}") from exc

    expected_tokens = {"{{PROJECT_TITLE}}"}
    expected_tokens.update(f"{{{{{token}}}}}" for token in FIELD_TOKENS.values())
    missing_tokens = sorted(token for token in expected_tokens if token not in template)
    if missing_tokens:
        raise BuildError(
            f"Briefing template is missing token(s): {', '.join(missing_tokens)}"
        )
    return template


def render_items(items: list[str]) -> str:
    if not items:
        return f'<p class="empty-state">{EMPTY_MESSAGE}</p>'

    rendered = "\n".join(
        f"            <li>{html.escape(item, quote=True)}</li>" for item in items
    )
    return f'<ul class="item-list">\n{rendered}\n          </ul>'


def render_briefing(payload: dict[str, Any], template: str) -> str:
    replacements = {
        "PROJECT_TITLE": html.escape(payload[PROJECT_TITLE], quote=True),
    }
    replacements.update(
        {
            FIELD_TOKENS[field]: render_items(payload[field])
            for field in LIST_FIELDS
        }
    )

    def substitute(match: re.Match[str]) -> str:
        token = match.group(1)
        if token not in replacements:
            raise BuildError(f"Unresolved template token: {match.group(0)}")
        return replacements[token]

    return TOKEN_PATTERN.sub(substitute, template)


def atomic_write(path: Path, content: str) -> None:
    temporary_path: Path | None = None
    try:
        file_descriptor, temporary_name = tempfile.mkstemp(
            dir=str(path.parent),
            prefix=f".{path.name}.",
            suffix=".tmp",
            text=True,
        )
        temporary_path = Path(temporary_name)
        with os.fdopen(
            file_descriptor,
            mode="w",
            encoding="utf-8",
            newline="\n",
        ) as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
        temporary_path = None
    except OSError as exc:
        raise BuildError(f"Could not write output HTML: {exc}") from exc
    finally:
        if temporary_path is not None:
            try:
                temporary_path.unlink()
            except FileNotFoundError:
                pass


def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print(
            "Usage: python3 scripts/build_briefing.py INPUT.json OUTPUT.html",
            file=sys.stderr,
        )
        return 2

    input_path = Path(argv[1])
    output_path = Path(argv[2])

    try:
        payload = validate_input(load_input(input_path))
    except InputError as exc:
        print(f"Input error: {exc}", file=sys.stderr)
        return 2

    try:
        template = load_template()
        rendered = render_briefing(payload, template)
        atomic_write(output_path, rendered)
    except BuildError as exc:
        print(f"Build error: {exc}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
